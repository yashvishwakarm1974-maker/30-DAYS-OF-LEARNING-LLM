# 30 Days of LLM Learning

A beginner-friendly, hands-on journey through Large Language Models (LLMs), from fundamentals to practical AI applications.

## Learning goals
- Understand how LLMs process and generate text.
- Learn tokens, embeddings, transformers, attention, and prompting.
- Explore practical Python examples.
- Gradually build small AI applications.

## 30-day learning path

| Day | Topic | Status |
|---|---|---|
| 01 | Introduction to LLMs and tokenization | In progress |
| 02 | How LLMs generate text | Planned |
| 03 | Tokens and tokenization in depth | Planned |
| 04 | Embeddings | Planned |
| 05 | Neural networks basics | Planned |
| 06 | Transformer architecture | Planned |
| 07 | Attention mechanism | Planned |

More topics will be added as the series progresses.

## Day 01: LLM fundamentals

An LLM (Large Language Model) is a machine-learning model trained on large collections of data to understand and generate language.

### Basic workflow

```mermaid
flowchart LR
    A[User prompt] --> B[Tokenization]
    B --> C[Token IDs]
    C --> D[Embeddings]
    D --> E[Transformer layers]
    E --> F[Next-token prediction]
    F --> G[Generated response]
```

1. **Input:** A user provides text.
2. **Tokenization:** The text is split into tokens.
3. **Token IDs and embeddings:** Tokens are represented numerically.
4. **Transformer:** The model processes context and relationships using attention.
5. **Generation:** The model predicts and produces output one token at a time.

> This is a simplified overview. Actual model architectures and generation pipelines vary.

## Run the example

### 1. Clone the repository

```bash
git clone https://github.com/YOUR-USERNAME/30-days-of-llm-learning.git
cd 30-days-of-llm-learning
```

### 2. Install dependencies

```bash
python -m pip install -r requirements.txt
```

### 3. Run Day 01

```bash
python Day-01/tokenization.py
```

## Repository structure

```text
30-days-of-llm-learning/
├── README.md
├── requirements.txt
├── .gitignore
└── Day-01/
    ├── introduction.md
    └── tokenization.py
```

## Tools
- Python
- tiktoken
- Git and GitHub

## Progress
- [x] Day 01 notes and tokenization example
- [ ] Day 02

## Author
Maintained as a personal learning project. Concepts, code, and examples will be added as I learn.

## Disclaimer
This repository is for educational purposes. LLMs can produce incorrect or misleading answers; always verify important information.
