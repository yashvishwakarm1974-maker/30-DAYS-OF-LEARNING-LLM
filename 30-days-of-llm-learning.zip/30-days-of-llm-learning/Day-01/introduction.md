# Day 01 — Introduction to Large Language Models

## What is an LLM?

LLM stands for **Large Language Model**. It is a model trained on large amounts of data to learn language patterns and generate text.

Examples of LLM families and services include GPT, Gemini, Claude, and Llama.

## What can LLMs do?
- Answer questions
- Summarize and explain text
- Help draft and transform content
- Generate and explain code
- Support language translation

## Important terms

| Term | Meaning |
|---|---|
| LLM | Large Language Model |
| NLP | Natural Language Processing |
| Token | A unit of text processed by a model |
| Tokenization | Splitting text into tokens |
| Embedding | A numerical representation of a token or other data |
| Transformer | A neural-network architecture used by many modern LLMs |
| Attention | A mechanism that helps a model weigh contextual relationships |
| Training | Adjusting model parameters using data |
| Fine-tuning | Further training an existing model for a task or domain |
| Inference | Using a trained model to produce an output |
| Prompt | Input or instructions supplied to a model |

## How does an LLM respond?

A simplified explanation:

1. The user submits a prompt.
2. A tokenizer converts text into token IDs.
3. The model maps token IDs to embeddings.
4. Transformer layers process the sequence and its context.
5. The model predicts a likely next token.
6. The process repeats until the response is complete.

## Practical task

Run `tokenization.py`, change the input sentence, and compare the token count. Notice that one word does not always equal one token.

## Key takeaway

LLMs do not simply search for a pre-written answer. They generate text by predicting tokens based on patterns learned during training and the context provided.
