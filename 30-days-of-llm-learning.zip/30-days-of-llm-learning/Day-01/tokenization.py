"""A small demonstration of text tokenization with tiktoken.

Install:
    python -m pip install -r requirements.txt

Run:
    python Day-01/tokenization.py
"""

import tiktoken


def main() -> None:
    text = "Hello, I am learning Large Language Models!"

    # cl100k_base is used by some models; tokenizers vary across models.
    encoding = tiktoken.get_encoding("cl100k_base")
    token_ids = encoding.encode(text)

    print("Original text:", text)
    print("Token IDs:", token_ids)
    print("Token count:", len(token_ids))
    print("Decoded text:", encoding.decode(token_ids))


if __name__ == "__main__":
    main()
